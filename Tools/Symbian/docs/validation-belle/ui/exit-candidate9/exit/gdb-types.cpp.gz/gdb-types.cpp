#include <kernel/kernel.h>
#include <kernel/thread.h>
#include <kernel/process.h>
#include <kernel/scheduler.h>
eka2l1::kernel_system* kern_types;
eka2l1::kernel::thread* thread_types;
eka2l1::kernel::process* process_types;

unsigned force_thread_debug(eka2l1::kernel::thread* p) { return p->get_thread_context().get_pc()+sizeof(*p); }
