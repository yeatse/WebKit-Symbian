set pagination off
set debuginfod enabled off
add-symbol-file /workspace/symbian-belle-work/ui-extra-candidate9/exit/gdb-types.o 0
python
import gdb
for thread in gdb.selected_inferior().threads():
 thread.switch()
 frame=gdb.newest_frame()
 while frame:
  if frame.name() and 'thread_scheduler::switch_context' in frame.name():
   frame.select()
   scheduler=gdb.parse_and_eval('$rbx').cast(gdb.lookup_type('eka2l1::kernel::thread_scheduler').pointer())
   kern=scheduler['kern']
   print('SCHEDULER',scheduler,'KERNEL',kern)
   start=kern['threads_']['_M_impl']['_M_start'].cast(gdb.lookup_type('void').pointer().pointer())
   end=kern['threads_']['_M_impl']['_M_finish'].cast(gdb.lookup_type('void').pointer().pointer())
   count=int(end-start)
   print('THREAD COUNT',count)
   for i in range(count):
    obj=start[i].cast(gdb.lookup_type('eka2l1::kernel::thread').pointer())
    print('GUEST THREAD',i,obj)
    print(obj.dereference())
   break
  frame=frame.older()
 else: continue
 break
end
detach
