set pagination off
set debuginfod enabled off
add-symbol-file /workspace/symbian-belle-work/ui-extra-candidate9/exit/gdb-types.o 0
python
import gdb
for thread in gdb.selected_inferior().threads():
 thread.switch()
 frame=gdb.newest_frame()
 while frame:
  if frame.name() and 'thread_scheduler::switch_context' in frame.name():
   frame.select()
   scheduler=gdb.parse_and_eval('$rbx').cast(gdb.lookup_type('eka2l1::kernel::thread_scheduler').pointer())
   kern=scheduler['kern']
   print('SCHEDULER',scheduler,'KERNEL',kern)
   start=kern['threads_']['_M_impl']['_M_start'].cast(gdb.lookup_type('void').pointer().pointer())
   end=kern['threads_']['_M_impl']['_M_finish'].cast(gdb.lookup_type('void').pointer().pointer())
   count=int(end-start)
   print('THREAD COUNT',count)
   for i in range(count):
    obj=start[i].cast(gdb.lookup_type('eka2l1::kernel::thread').pointer())
    name=obj['obj_name']['_M_dataplus']['_M_p'].string()
    owner=obj['owner']
    ownername=owner['obj_name']['_M_dataplus']['_M_p'].string() if int(owner) else '<none>'
    regs=obj['ctx']['cpu_registers']['_M_elems']
    print('GUEST THREAD',i,obj,'name',name,'owner',ownername,owner,'state',obj['state'],'PC/LR/SP',hex(int(regs[15])),hex(int(regs[14])),hex(int(regs[13])))
    if 'browser' in ownername.lower():
     print('REGS', ' '.join('r%d=%08x'%(r,int(regs[r])) for r in range(16)))
     wait=obj['wait_obj'];print('WAIT',wait)
     if int(wait):print('WAIT OBJ',wait.dereference())
     print('REQUEST SEMA',obj['request_sema'],'SYNC MSG',obj['sync_msg'])
     if int(obj['sync_msg']): print('SYNC MESSAGE', obj['sync_msg'].dereference())
     if name in ('Main','WebKit'):
      sp=int(regs[13]); ptr=gdb.parse_and_eval("((void*(*)(void*,unsigned int))'eka2l1::kernel::process::get_ptr_on_addr_space(unsigned int)')(%d,%d)"%(int(owner),sp-64))
      print('MAIN STACK',hex(sp-64),ptr)
      gdb.execute('x/128wx %d'%int(ptr))
      gdb.execute('dump binary memory /workspace/symbian-belle-work/ui-extra-candidate9/exit-state-diagnostic/guest-main-stack.bin %d %d'%(int(ptr),int(ptr)+512))
   break
  frame=frame.older()
 else: continue
 break
end
detach
